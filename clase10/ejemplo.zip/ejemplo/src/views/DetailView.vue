<template>
  <h2>Detail Page</h2>
  {{ $route.params.code }}
</template>

<script>
export default {

}
</script>

<style>

</style>